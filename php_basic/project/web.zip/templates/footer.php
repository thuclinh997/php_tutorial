<footer class="section">
    <div class="center grey-text">Copyright 2021 Ninja Pizzas</div>
</footer>
</body>
